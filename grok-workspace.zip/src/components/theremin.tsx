import { useLayoutEffect, useRef, useState, type KeyboardEvent as ReactKeyboardEvent, type PointerEvent as ReactPointerEvent } from "react";
import { Volume2, VolumeX } from "lucide-react";
import { clsx } from "clsx";
import {
  GUIDE_LINES,
  HOME_X,
  HOME_Y,
  LOW_MIDI,
  PITCH_TICKS,
  SEMITONES,
  describeX,
  formatCents,
  clamp01,
} from "@/lib/pitch";
import {
  ThereminEngine,
  parseWaveform,
  type WaveformId,
} from "@/lib/theremin-audio";

const STORAGE_KEY = "aether-settings-v1";

const WAVES: { id: WaveformId; label: string; hint: string }[] = [
  { id: "sine", label: "Sine", hint: "Pure tone" },
  { id: "soft", label: "Soft", hint: "Rounded triangle" },
  { id: "saw", label: "Saw", hint: "Bright sawtooth" },
  { id: "square", label: "Square", hint: "Hollow reed" },
  { id: "duo", label: "Duo", hint: "Two detuned saws" },
];

type Hand = { x: number; y: number; sounding: boolean };

type Settings = { waveform: WaveformId; reverb: number; vibrato: number };

const DEFAULTS: Settings = { waveform: "sine", reverb: 0.36, vibrato: 0.4 };

function loadSettings(): Settings | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<Settings>;
    const waveform = parseWaveform(parsed.waveform);
    if (!waveform) return null;
    if (typeof parsed.reverb !== "number" || typeof parsed.vibrato !== "number") return null;
    return {
      waveform,
      reverb: clamp01(parsed.reverb),
      vibrato: clamp01(parsed.vibrato),
    };
  } catch {
    return null;
  }
}

function saveSettings(settings: Settings) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  } catch {
    /* private mode / quota */
  }
}

export function Theremin() {
  const engineRef = useRef<ThereminEngine | null>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const frameRef = useRef(0);
  const pendingRef = useRef<Hand | null>(null);
  const xRef = useRef(HOME_X);
  const yRef = useRef(HOME_Y);
  const insideRef = useRef(false);
  const touchingRef = useRef(false);
  const awakeRef = useRef(false);
  const mutedRef = useRef(false);
  const settingsRef = useRef<Settings>(DEFAULTS);
  const toggleMuteRef = useRef<() => void>(() => {});

  const [hand, setHand] = useState<Hand>({ x: HOME_X, y: HOME_Y, sounding: false });
  const [awake, setAwake] = useState(false);
  const [muted, setMuted] = useState(false);
  const [waveform, setWaveform] = useState<WaveformId>(DEFAULTS.waveform);
  const [reverb, setReverb] = useState(DEFAULTS.reverb);
  const [vibrato, setVibrato] = useState(DEFAULTS.vibrato);
  const [audioError, setAudioError] = useState(false);

  settingsRef.current = { waveform, reverb, vibrato };
  awakeRef.current = awake;
  mutedRef.current = muted;

  useLayoutEffect(() => {
    const engine = new ThereminEngine();
    engineRef.current = engine;
    const saved = loadSettings();
    if (saved) {
      settingsRef.current = saved;
      setWaveform(saved.waveform);
      setReverb(saved.reverb);
      setVibrato(saved.vibrato);
    }
    const initial = settingsRef.current;
    engine.setWaveform(initial.waveform);
    engine.setReverb(initial.reverb);
    engine.setVibrato(initial.vibrato);

    const onVis = () => {
      engine.setPageVisible(document.visibilityState !== "hidden");
    };
    const onKey = (event: KeyboardEvent) => {
      if (event.key.toLowerCase() !== "m") return;
      const target = event.target;
      if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) return;
      event.preventDefault();
      toggleMuteRef.current();
    };
    document.addEventListener("visibilitychange", onVis);
    window.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("keydown", onKey);
      if (frameRef.current) cancelAnimationFrame(frameRef.current);
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  function commit(x: number, y: number, sounding: boolean) {
    xRef.current = x;
    yRef.current = y;
    engineRef.current?.setHand(x, y, sounding);
    pendingRef.current = { x, y, sounding };
    if (frameRef.current) return;
    frameRef.current = requestAnimationFrame(() => {
      frameRef.current = 0;
      const next = pendingRef.current;
      if (!next) return;
      setHand((prev) =>
        prev.x === next.x && prev.y === next.y && prev.sounding === next.sounding ? prev : next,
      );
    });
  }

  function wake() {
    const ok = engineRef.current?.unlock() ?? false;
    if (!ok) setAudioError(true);
    if (!awakeRef.current) {
      awakeRef.current = true;
      setAwake(true);
    }
  }

  function toggleMute() {
    const next = !mutedRef.current;
    mutedRef.current = next;
    setMuted(next);
    const sounding = !next && awakeRef.current && insideRef.current;
    commit(xRef.current, yRef.current, sounding);
  }
  toggleMuteRef.current = toggleMute;

  function pointFromEvent(event: ReactPointerEvent<HTMLDivElement>) {
    const rect = event.currentTarget.getBoundingClientRect();
    const rawX = rect.width ? (event.clientX - rect.left) / rect.width : 0;
    const rawY = rect.height ? (event.clientY - rect.top) / rect.height : 0;
    const inside = rawX >= 0 && rawX <= 1 && rawY >= 0 && rawY <= 1;
    return { x: clamp01(rawX), y: clamp01(rawY), inside };
  }

  function onPointerDown(event: ReactPointerEvent<HTMLDivElement>) {
    if (event.pointerType !== "mouse") event.preventDefault();
    wake();
    event.currentTarget.focus({ preventScroll: true });
    if (event.pointerType !== "mouse") {
      touchingRef.current = true;
      event.currentTarget.setPointerCapture(event.pointerId);
    }
    const point = pointFromEvent(event);
    insideRef.current = point.inside;
    const sounding = point.inside && !mutedRef.current;
    commit(point.x, point.y, sounding);
  }

  function onPointerMove(event: ReactPointerEvent<HTMLDivElement>) {
    const isMouse = event.pointerType === "mouse";
    if (!isMouse && !touchingRef.current) return;
    const point = pointFromEvent(event);
    insideRef.current = point.inside;
    const engaged = isMouse || touchingRef.current;
    const sounding = engaged && point.inside && awakeRef.current && !mutedRef.current;
    commit(point.x, point.y, sounding);
  }

  function onPointerUp(event: ReactPointerEvent<HTMLDivElement>) {
    if (event.pointerType === "mouse") return;
    touchingRef.current = false;
    insideRef.current = false;
    commit(xRef.current, yRef.current, false);
  }

  function onPointerLeave(event: ReactPointerEvent<HTMLDivElement>) {
    if (event.pointerType !== "mouse" || touchingRef.current) return;
    insideRef.current = false;
    commit(xRef.current, yRef.current, false);
  }

  function onKeyDown(event: ReactKeyboardEvent<HTMLDivElement>) {
    const step = event.shiftKey ? 0.006 : 0.02;
    let x = xRef.current;
    let y = yRef.current;
    if (event.key === "ArrowLeft") x -= step;
    else if (event.key === "ArrowRight") x += step;
    else if (event.key === "ArrowUp") y -= step;
    else if (event.key === "ArrowDown") y += step;
    else return;
    event.preventDefault();
    wake();
    x = clamp01(x);
    y = clamp01(y);
    insideRef.current = true;
    commit(x, y, !mutedRef.current);
  }

  function chooseWave(id: WaveformId) {
    setWaveform(id);
    engineRef.current?.setWaveform(id);
    saveSettings({ ...settingsRef.current, waveform: id });
  }

  function changeReverb(value: number) {
    const next = clamp01(value);
    setReverb(next);
    engineRef.current?.setReverb(next);
    saveSettings({ ...settingsRef.current, reverb: next });
  }

  function changeVibrato(value: number) {
    const next = clamp01(value);
    setVibrato(next);
    engineRef.current?.setVibrato(next);
    saveSettings({ ...settingsRef.current, vibrato: next });
  }

  const pitch = describeX(hand.x);
  const laneX = (pitch.nearestMidi - LOW_MIDI) / SEMITONES;
  const loudness = 1 - hand.y;
  const handScale = 0.72 + loudness * 0.5;
  const wave = WAVES.find((item) => item.id === waveform) ?? WAVES[0];
  const status = audioError
    ? "Audio unavailable"
    : muted
      ? "Muted"
      : !awake
        ? "Press the field"
        : hand.sounding
          ? ""
          : "Hand away";
  const meta = status
    ? `${pitch.hz} Hz · ${formatCents(pitch.cents)} · ${status}`
    : `${pitch.hz} Hz · ${formatCents(pitch.cents)}`;
  const live = hand.sounding
    ? `${pitch.note}. Sounding`
    : muted
      ? `${pitch.note}. Muted`
      : !awake
        ? `${pitch.note}. Press the field`
        : `${pitch.note}. Silent`;

  return (
    <main className="safe-bottom mx-auto flex min-h-dvh w-full flex-col px-3 pt-4 sm:px-6 sm:pt-6">
      <p className="sr-only" aria-live="polite">
        {live}
      </p>
      <header className="mb-3 flex flex-wrap items-center gap-x-3 gap-y-1 sm:mb-4 sm:flex-nowrap">
        <div className="min-w-0">
          <h1 className="font-display text-3xl leading-none tracking-tight text-balance text-fg sm:text-4xl">
            Aether
          </h1>
          <p className="mt-1 text-sm text-muted">Field theremin</p>
        </div>
        <button
          type="button"
          aria-pressed={muted}
          aria-label={muted ? "Unmute" : "Mute"}
          onClick={() => {
            const ok = engineRef.current?.unlock() ?? false;
            if (!ok) setAudioError(true);
            toggleMute();
          }}
          className={clsx(
            "ml-auto inline-flex h-11 shrink-0 items-center gap-2 rounded-full pr-4 pl-3.5 text-sm font-medium transition-[background-color,color,scale] duration-150 ease-out active:scale-[0.96] sm:order-3 sm:ml-0",
            muted ? "bg-brass text-bg" : "bg-panel text-fg shadow-panel",
          )}
        >
          <MuteGlyph muted={muted} />
          <span className="inline-grid">
            <span className={clsx("col-start-1 row-start-1", muted && "invisible")}>Mute</span>
            <span className={clsx("col-start-1 row-start-1", !muted && "invisible")}>Muted</span>
          </span>
        </button>
        <div className="order-3 w-full text-center sm:order-2 sm:w-auto sm:flex-1">
          <div className="relative inline-block">
            <span
              className={clsx(
                "tone-dot absolute top-1/2 -left-4 size-2 -translate-y-1/2 rounded-full bg-brass",
                hand.sounding ? "opacity-100" : "opacity-0",
              )}
              aria-hidden="true"
            />
            <p
              className="font-display text-4xl leading-none tabular-nums text-fg sm:text-5xl"
              data-note={pitch.note}
              data-hz={pitch.hz}
              data-sounding={hand.sounding ? "true" : "false"}
            >
              {pitch.note}
            </p>
          </div>
          <p className="mt-1 text-sm tabular-nums text-muted">{meta}</p>
        </div>
      </header>

      <section className="flex min-h-96 flex-1 flex-col overflow-hidden rounded-3xl bg-panel shadow-panel">
        <div className="flex min-h-0 flex-1">
          <div className="flex w-12 shrink-0 flex-col items-center gap-2 py-3">
            <span className="text-xs font-medium text-muted">Loud</span>
            <div className="relative w-1 flex-1 rounded-full bg-fg/10" aria-hidden="true">
              <div
                className="absolute inset-x-0 bottom-0 rounded-full bg-brass"
                style={{ height: `${loudness * 100}%` }}
              />
            </div>
            <span className="text-xs font-medium text-muted">Soft</span>
          </div>

          <div
            ref={stageRef}
            role="application"
            tabIndex={0}
            aria-label="Play field. Move across to change pitch and up to raise volume. Arrow keys move the tone."
            aria-describedby="field-legend"
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerCancel={onPointerUp}
            onPointerLeave={onPointerLeave}
            onKeyDown={onKeyDown}
            className="stage relative min-w-0 flex-1 cursor-crosshair touch-none select-none outline-none focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-brass"
            style={{ ["--halo" as string]: `${8 + reverb * 36}px` }}
          >
            {GUIDE_LINES.map((line) => (
              <div
                key={line.midi}
                className={clsx(
                  "pointer-events-none absolute inset-y-0 w-px",
                  line.kind === "c" ? "bg-brass/40" : "bg-fg/10",
                )}
                style={{ left: `${line.x * 100}%` }}
              />
            ))}
            {[25, 50, 75].map((mark) => (
              <div
                key={mark}
                className="pointer-events-none absolute inset-x-0 h-px bg-fg/10"
                style={{ top: `${mark}%` }}
              />
            ))}
            <div
              className="pointer-events-none absolute inset-y-0 bg-brass/15"
              style={{
                left: `${laneX * 100}%`,
                width: `${100 / SEMITONES}%`,
                transform: "translateX(-50%)",
              }}
            />
            <div
              className={clsx(
                "pointer-events-none absolute inset-y-0 w-0.5 -translate-x-1/2 bg-brass",
                hand.sounding ? "opacity-80" : "opacity-35",
              )}
              style={{ left: `${hand.x * 100}%` }}
            />
            <div
              className={clsx(
                "pointer-events-none absolute inset-x-0 h-0.5 -translate-y-1/2 bg-brass",
                hand.sounding ? "opacity-70" : "opacity-30",
              )}
              style={{ top: `${hand.y * 100}%` }}
            />
            <div
              className={clsx(
                "hand pointer-events-none absolute size-16 rounded-full sm:size-20",
                hand.sounding ? "opacity-95" : "opacity-50",
              )}
              style={{
                left: `${hand.x * 100}%`,
                top: `${hand.y * 100}%`,
                transform: `translate(-50%, -50%) scale(${handScale})`,
              }}
            >
              <span className="absolute top-1/2 left-1/2 size-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-fg" />
            </div>
            <span className="pointer-events-none absolute bottom-3 left-3 text-xs font-medium text-muted">
              Low
            </span>
            <span className="pointer-events-none absolute right-3 bottom-3 text-xs font-medium text-muted">
              High
            </span>
          </div>
        </div>

        <div className="relative ml-12 h-12 border-t border-fg/10" aria-hidden="true">
          {PITCH_TICKS.map((tick) => (
            <div
              key={tick.midi}
              className="absolute top-0 flex flex-col items-center"
              style={{
                left: `${tick.x * 100}%`,
                transform:
                  tick.x === 0 ? "none" : tick.x === 1 ? "translateX(-100%)" : "translateX(-50%)",
              }}
            >
              <span
                className={clsx(
                  "w-px",
                  tick.kind === "c"
                    ? "h-3 bg-brass"
                    : tick.kind === "natural"
                      ? "h-2 bg-fg/30"
                      : "h-1.5 bg-fg/15",
                )}
              />
              {tick.label ? (
                <span
                  className={clsx(
                    "mt-1 text-xs leading-none tabular-nums",
                    tick.kind === "c" ? "text-muted" : "hidden text-fg/45 sm:block",
                  )}
                >
                  {tick.label}
                </span>
              ) : null}
            </div>
          ))}
        </div>
      </section>

      <p id="field-legend" className="mt-3 text-center text-sm text-pretty text-muted">
        Left is low pitch, right is high. Bottom is soft, top is loud.
      </p>
      <p className="mt-1 hidden text-center text-xs text-muted sm:block">
        Arrow keys move the tone. M mutes. Hold Shift for smaller steps.
      </p>

      <section className="mt-3 rounded-2xl bg-panel px-3 py-3 shadow-panel sm:px-4">
        <div className="mb-2 flex items-baseline justify-between gap-3">
          <h2 className="text-sm font-medium text-fg">Wave</h2>
          <p className="text-sm text-muted">{wave?.hint}</p>
        </div>
        <div className="grid grid-cols-5 gap-1 rounded-full bg-inset p-1" role="group" aria-label="Waveform">
          {WAVES.map((item) => {
            const selected = item.id === waveform;
            return (
              <button
                key={item.id}
                type="button"
                aria-pressed={selected}
                onClick={() => chooseWave(item.id)}
                className={clsx(
                  "min-h-11 rounded-full px-1 text-xs font-medium whitespace-nowrap transition-[background-color,color,scale] duration-150 ease-out active:scale-[0.96] sm:text-sm",
                  selected ? "bg-brass text-bg" : "text-muted hover:bg-bg hover:text-fg",
                )}
              >
                {item.label}
              </button>
            );
          })}
        </div>

        <div className="mt-3 grid grid-cols-2 gap-4">
          <label className="block min-w-0">
            <span className="mb-1 flex items-baseline justify-between gap-2 text-sm">
              <span className="font-medium text-fg">Room</span>
              <span className="tabular-nums text-muted">{Math.round(reverb * 100)}</span>
            </span>
            <input
              type="range"
              min={0}
              max={100}
              value={Math.round(reverb * 100)}
              aria-label="Reverb amount"
              aria-valuetext={`${Math.round(reverb * 100)} percent`}
              onChange={(event) => changeReverb(Number(event.target.value) / 100)}
            />
          </label>
          <label className="block min-w-0">
            <span className="mb-1 flex items-baseline justify-between gap-2 text-sm">
              <span className="font-medium text-fg">Vibrato</span>
              <span className="tabular-nums text-muted">{Math.round(vibrato * 100)}</span>
            </span>
            <input
              type="range"
              min={0}
              max={100}
              value={Math.round(vibrato * 100)}
              aria-label="Vibrato depth"
              aria-valuetext={`${Math.round(vibrato * 100)} percent`}
              onChange={(event) => changeVibrato(Number(event.target.value) / 100)}
            />
          </label>
        </div>
      </section>
    </main>
  );
}

function MuteGlyph({ muted }: { muted: boolean }) {
  return (
    <span className="relative grid size-5 place-items-center" aria-hidden="true">
      <VolumeX
        className={clsx(
          "col-start-1 row-start-1 size-5 transition-[opacity,scale,filter] duration-300 ease-[cubic-bezier(0.2,0,0,1)]",
          muted ? "scale-100 opacity-100 blur-none" : "scale-[0.25] opacity-0 blur-[4px]",
        )}
        strokeWidth={2}
      />
      <Volume2
        className={clsx(
          "col-start-1 row-start-1 size-5 transition-[opacity,scale,filter] duration-300 ease-[cubic-bezier(0.2,0,0,1)]",
          muted ? "scale-[0.25] opacity-0 blur-[4px]" : "scale-100 opacity-100 blur-none",
        )}
        strokeWidth={2}
      />
    </span>
  );
}
