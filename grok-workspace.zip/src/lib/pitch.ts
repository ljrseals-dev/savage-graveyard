/** Playable span: C3 through C6, three octaves. */
export const LOW_MIDI = 48;
export const HIGH_MIDI = 84;
export const SEMITONES = HIGH_MIDI - LOW_MIDI;

/** Home pose sits on A4 so the idle readout is a recognizable pitch. */
export const HOME_MIDI = 69;
export const HOME_X = (HOME_MIDI - LOW_MIDI) / SEMITONES;
export const HOME_Y = 0.34;

const NAMES = [
  "C",
  "C♯",
  "D",
  "D♯",
  "E",
  "F",
  "F♯",
  "G",
  "G♯",
  "A",
  "A♯",
  "B",
] as const;

export type PitchReadout = {
  note: string;
  cents: number;
  hz: number;
  nearestMidi: number;
};

export type TickKind = "c" | "natural" | "sharp";

export type PitchTick = {
  midi: number;
  x: number;
  kind: TickKind;
  label: string;
};

export function clamp01(n: number): number {
  if (n < 0) return 0;
  if (n > 1) return 1;
  return n;
}

export function midiToFreq(midi: number): number {
  return 440 * 2 ** ((midi - 69) / 12);
}

export function xToMidi(x: number): number {
  return LOW_MIDI + clamp01(x) * SEMITONES;
}

export function xToFreq(x: number): number {
  return midiToFreq(xToMidi(x));
}

export function describeX(x: number): PitchReadout {
  const midiFloat = xToMidi(x);
  const nearest = Math.round(midiFloat);
  const cents = Math.round((midiFloat - nearest) * 100);
  const name = NAMES[((nearest % 12) + 12) % 12];
  const oct = Math.floor(nearest / 12) - 1;
  const freq = midiToFreq(midiFloat);
  return {
    note: `${name}${oct}`,
    cents,
    hz: Math.round(freq),
    nearestMidi: nearest,
  };
}

export function formatCents(cents: number): string {
  if (cents > 0) return `+${cents}¢`;
  if (cents < 0) return `−${Math.abs(cents)}¢`;
  return "0¢";
}

/** Perceived loudness tracks vertical position. Top is loud. */
export function volumeFromY(y: number): number {
  const loudness = 1 - clamp01(y);
  const lifted = Math.max(0, (loudness - 0.03) / 0.97);
  return lifted ** 1.6;
}

function buildTicks(): PitchTick[] {
  const ticks: PitchTick[] = [];
  for (let midi = LOW_MIDI; midi <= HIGH_MIDI; midi++) {
    const pc = midi % 12;
    const name = NAMES[pc] ?? "C";
    const sharp = name.includes("♯");
    const isC = pc === 0;
    const oct = Math.floor(midi / 12) - 1;
    ticks.push({
      midi,
      x: (midi - LOW_MIDI) / SEMITONES,
      kind: isC ? "c" : sharp ? "sharp" : "natural",
      label: isC ? `${name}${oct}` : sharp ? "" : name,
    });
  }
  return ticks;
}

export const PITCH_TICKS = buildTicks();

export const GUIDE_LINES = PITCH_TICKS.filter((tick) => {
  if (tick.x <= 0 || tick.x >= 1) return false;
  const pc = tick.midi % 12;
  return pc === 0 || pc === 5;
});
