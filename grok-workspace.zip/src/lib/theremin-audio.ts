import { volumeFromY, xToFreq, clamp01 } from "@/lib/pitch";

export const WAVEFORMS = ["sine", "soft", "saw", "square", "duo"] as const;
export type WaveformId = (typeof WAVEFORMS)[number];

type Shape = {
  a: OscillatorType;
  b: OscillatorType | null;
  detune: number;
  aGain: number;
  bGain: number;
  /** Cutoff as a multiple of the played frequency. Ignored when fixedCutoff is set. */
  filterMul: number;
  filterQ: number;
  fixedCutoff?: number;
};

const SHAPES: Record<WaveformId, Shape> = {
  sine: {
    a: "sine",
    b: null,
    detune: 0,
    aGain: 0.82,
    bGain: 0,
    filterMul: 0,
    filterQ: 0.4,
    fixedCutoff: 12000,
  },
  soft: {
    a: "triangle",
    b: null,
    detune: 0,
    aGain: 0.58,
    bGain: 0,
    filterMul: 8,
    filterQ: 0.35,
  },
  saw: {
    a: "sawtooth",
    b: null,
    detune: 0,
    aGain: 0.24,
    bGain: 0,
    filterMul: 4.6,
    filterQ: 0.65,
  },
  square: {
    a: "square",
    b: null,
    detune: 0,
    aGain: 0.18,
    bGain: 0,
    filterMul: 2.7,
    filterQ: 1.7,
  },
  duo: {
    a: "sawtooth",
    b: "sawtooth",
    detune: 9,
    aGain: 0.16,
    bGain: 0.13,
    filterMul: 4.2,
    filterQ: 0.75,
  },
};

const MAX_VIBRATO_CENTS = 30;

function isWaveform(value: string): value is WaveformId {
  return (WAVEFORMS as readonly string[]).includes(value);
}

export function parseWaveform(value: unknown): WaveformId | null {
  return typeof value === "string" && isWaveform(value) ? value : null;
}

function makeHall(ctx: AudioContext): AudioBuffer {
  const rate = ctx.sampleRate;
  const seconds = 2.15;
  const length = Math.floor(rate * seconds);
  const buffer = ctx.createBuffer(2, length, rate);
  const echoes = [0.013, 0.019, 0.029, 0.041, 0.057, 0.079];

  for (let ch = 0; ch < 2; ch++) {
    const data = buffer.getChannelData(ch);
    let seed = ch === 0 ? 19 : 97;
    const rand = () => {
      seed = (seed * 16807 + 11) % 2147483647;
      return (seed / 2147483647) * 2 - 1;
    };
    let lp = 0;
    let hp = 0;
    for (let i = 0; i < length; i++) {
      const t = i / rate;
      const n = rand();
      const coeff = 0.07 + 0.62 * Math.min(1, t / 1.2);
      lp += coeff * (n - lp);
      hp += 0.012 * (lp - hp);
      const body = (lp - hp) * Math.exp(-t * 2.15);
      data[i] = body;
    }
    for (let idx = 0; idx < echoes.length; idx++) {
      const time = echoes[idx] ?? 0;
      const at = Math.floor((time + ch * 0.0037) * rate);
      if (at >= 0 && at < length) {
        const sign = idx % 2 === 0 ? 1 : -1;
        data[at] += sign * 0.42 * Math.exp(-idx * 0.32);
      }
    }
  }

  let peak = 0;
  for (let ch = 0; ch < 2; ch++) {
    const data = buffer.getChannelData(ch);
    for (let i = 0; i < data.length; i++) peak = Math.max(peak, Math.abs(data[i] ?? 0));
  }
  if (peak > 1e-5) {
    const norm = 0.8 / peak;
    for (let ch = 0; ch < 2; ch++) {
      const data = buffer.getChannelData(ch);
      for (let i = 0; i < data.length; i++) data[i] = (data[i] ?? 0) * norm;
    }
  }
  return buffer;
}

function ramp(param: AudioParam, value: number, now: number, tc: number) {
  param.setTargetAtTime(value, now, tc);
}

/**
 * Continuous theremin voice. The AudioContext is created on the first user
 * gesture so mobile browsers actually unblock sound.
 */
export class ThereminEngine {
  private ctx: AudioContext | null = null;
  private oscA: OscillatorNode | null = null;
  private oscB: OscillatorNode | null = null;
  private gainA: GainNode | null = null;
  private gainB: GainNode | null = null;
  private filter: BiquadFilterNode | null = null;
  private voice: GainNode | null = null;
  private panner: StereoPannerNode | null = null;
  private dry: GainNode | null = null;
  private wet: GainNode | null = null;
  private lfo: OscillatorNode | null = null;
  private lfoDepth: GainNode | null = null;

  private waveform: WaveformId = "sine";
  private reverb = 0.36;
  private vibrato = 0.4;
  private x = 0.5;
  private y = 0.5;
  private active = false;
  private pageVisible = true;

  unlock(): boolean {
    try {
      const w = window as Window & { webkitAudioContext?: typeof AudioContext };
      const Ctor = window.AudioContext ?? w.webkitAudioContext;
      if (!Ctor) return false;
      if (!this.ctx) {
        this.ctx = new Ctor({ latencyHint: "interactive" });
        this.build(this.ctx);
      }
      if (this.ctx.state === "suspended") void this.ctx.resume();
      return true;
    } catch {
      return false;
    }
  }

  setWaveform(id: WaveformId) {
    this.waveform = id;
    this.applyShape(0.03);
    this.syncPitch(0.04);
  }

  setReverb(amount: number) {
    this.reverb = clamp01(amount);
    this.applyMix(0.06);
  }

  setVibrato(amount: number) {
    this.vibrato = clamp01(amount);
    this.syncPitch(0.05);
  }

  /** `active` is false when the hand is away, the instrument is muted, or audio is locked. */
  setHand(x: number, y: number, active: boolean) {
    this.x = clamp01(x);
    this.y = clamp01(y);
    this.active = active;
    this.syncPitch(0.018);
    this.syncLevel(active ? 0.03 : 0.055);
    this.syncPan(0.04);
  }

  setPageVisible(visible: boolean) {
    this.pageVisible = visible;
    if (visible && this.ctx?.state === "suspended") void this.ctx.resume();
    this.syncLevel(visible ? 0.04 : 0.03);
  }

  dispose() {
    const ctx = this.ctx;
    this.ctx = null;
    try {
      this.oscA?.stop();
      this.oscB?.stop();
      this.lfo?.stop();
    } catch {
      /* already stopped */
    }
    if (ctx) void ctx.close();
  }

  private build(ctx: AudioContext) {
    const oscA = ctx.createOscillator();
    const oscB = ctx.createOscillator();
    const gainA = ctx.createGain();
    const gainB = ctx.createGain();
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    const voice = ctx.createGain();
    voice.gain.value = 0;
    const panner = ctx.createStereoPanner();
    const dry = ctx.createGain();
    const wet = ctx.createGain();
    const predelay = ctx.createDelay(0.1);
    predelay.delayTime.value = 0.02;
    const wetHp = ctx.createBiquadFilter();
    wetHp.type = "highpass";
    wetHp.frequency.value = 180;
    const wetLp = ctx.createBiquadFilter();
    wetLp.type = "lowpass";
    wetLp.frequency.value = 6200;
    const convolver = ctx.createConvolver();
    convolver.buffer = makeHall(ctx);
    const sum = ctx.createGain();
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -16;
    comp.knee.value = 18;
    comp.ratio.value = 2.4;
    comp.attack.value = 0.006;
    comp.release.value = 0.2;
    const hip = ctx.createBiquadFilter();
    hip.type = "highpass";
    hip.frequency.value = 32;
    const master = ctx.createGain();
    master.gain.value = 0.78;

    const lfo = ctx.createOscillator();
    lfo.type = "sine";
    lfo.frequency.value = 5.35;
    const lfoDepth = ctx.createGain();
    lfoDepth.gain.value = 0;

    oscA.connect(gainA);
    oscB.connect(gainB);
    gainA.connect(filter);
    gainB.connect(filter);
    filter.connect(voice);
    voice.connect(panner);
    panner.connect(dry);
    dry.connect(sum);
    panner.connect(predelay);
    predelay.connect(wetHp);
    wetHp.connect(wetLp);
    wetLp.connect(convolver);
    convolver.connect(wet);
    wet.connect(sum);
    sum.connect(comp);
    comp.connect(hip);
    hip.connect(master);
    master.connect(ctx.destination);
    lfo.connect(lfoDepth);
    lfoDepth.connect(oscA.frequency);
    lfoDepth.connect(oscB.frequency);

    oscA.frequency.value = 440;
    oscB.frequency.value = 440;
    oscA.start();
    oscB.start();
    lfo.start();

    this.oscA = oscA;
    this.oscB = oscB;
    this.gainA = gainA;
    this.gainB = gainB;
    this.filter = filter;
    this.voice = voice;
    this.panner = panner;
    this.dry = dry;
    this.wet = wet;
    this.lfo = lfo;
    this.lfoDepth = lfoDepth;

    this.applyShape(0.01);
    this.applyMix(0.01);
    this.syncPitch(0.01);
    this.syncLevel(0.01);
    this.syncPan(0.01);
  }

  private now(): number | null {
    return this.ctx ? this.ctx.currentTime : null;
  }

  private applyShape(tc: number) {
    const now = this.now();
    if (!now || !this.oscA || !this.oscB || !this.gainA || !this.gainB || !this.filter) return;
    const shape = SHAPES[this.waveform];
    this.oscA.type = shape.a;
    this.oscB.type = shape.b ?? "sine";
    ramp(this.gainA.gain, shape.aGain, now, tc);
    ramp(this.gainB.gain, shape.b ? shape.bGain : 0, now, tc);
    ramp(this.oscB.detune, shape.detune, now, tc);
    ramp(this.filter.Q, shape.filterQ, now, tc);
  }

  private applyMix(tc: number) {
    const now = this.now();
    if (!now || !this.dry || !this.wet) return;
    ramp(this.wet.gain, this.reverb * 0.48, now, tc);
    ramp(this.dry.gain, 1 - this.reverb * 0.2, now, tc);
  }

  private syncPitch(tc: number) {
    const now = this.now();
    if (!now || !this.oscA || !this.oscB || !this.filter || !this.lfoDepth) return;
    const freq = xToFreq(this.x);
    ramp(this.oscA.frequency, freq, now, tc);
    ramp(this.oscB.frequency, freq, now, tc);
    const shape = SHAPES[this.waveform];
    const level = this.audibleLevel();
    const openness = 0.68 + 0.32 * Math.sqrt(level);
    const cutoff = shape.fixedCutoff
      ? shape.fixedCutoff
      : Math.min(8600, Math.max(380, freq * shape.filterMul * openness));
    ramp(this.filter.frequency, cutoff, now, 0.045);
    const cents = this.vibrato * MAX_VIBRATO_CENTS;
    const deviation = freq * cents * (Math.LN2 / 1200);
    ramp(this.lfoDepth.gain, deviation, now, 0.06);
  }

  private syncLevel(tc: number) {
    const now = this.now();
    if (!now || !this.voice) return;
    ramp(this.voice.gain, this.audibleLevel(), now, tc);
  }

  private syncPan(tc: number) {
    const now = this.now();
    if (!now || !this.panner) return;
    ramp(this.panner.pan, (this.x - 0.5) * 0.55, now, tc);
  }

  private audibleLevel(): number {
    if (!this.active || !this.pageVisible) return 0;
    return volumeFromY(this.y);
  }
}
