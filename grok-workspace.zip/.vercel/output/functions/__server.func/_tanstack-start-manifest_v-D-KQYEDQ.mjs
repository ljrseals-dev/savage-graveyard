//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D-KQYEDQ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-B8iNiWvw.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B8iNiWvw.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes--3sRh5c9.js"]
	}
} });
//#endregion
export { tsrStartManifest };
