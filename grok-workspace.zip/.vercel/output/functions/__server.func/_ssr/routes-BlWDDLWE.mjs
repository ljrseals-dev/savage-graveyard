import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Volume2, t as VolumeX } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BlWDDLWE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var HOME_X = 21 / 36;
var HOME_Y = .34;
var NAMES = [
	"C",
	"C♯",
	"D",
	"D♯",
	"E",
	"F",
	"F♯",
	"G",
	"G♯",
	"A",
	"A♯",
	"B"
];
function clamp01(n) {
	if (n < 0) return 0;
	if (n > 1) return 1;
	return n;
}
function midiToFreq(midi) {
	return 440 * 2 ** ((midi - 69) / 12);
}
function xToMidi(x) {
	return 48 + clamp01(x) * 36;
}
function xToFreq(x) {
	return midiToFreq(xToMidi(x));
}
function describeX(x) {
	const midiFloat = xToMidi(x);
	const nearest = Math.round(midiFloat);
	const cents = Math.round((midiFloat - nearest) * 100);
	const name = NAMES[(nearest % 12 + 12) % 12];
	const oct = Math.floor(nearest / 12) - 1;
	const freq = midiToFreq(midiFloat);
	return {
		note: `${name}${oct}`,
		cents,
		hz: Math.round(freq),
		nearestMidi: nearest
	};
}
function formatCents(cents) {
	if (cents > 0) return `+${cents}¢`;
	if (cents < 0) return `−${Math.abs(cents)}¢`;
	return "0¢";
}
/** Perceived loudness tracks vertical position. Top is loud. */
function volumeFromY(y) {
	const loudness = 1 - clamp01(y);
	return Math.max(0, (loudness - .03) / .97) ** 1.6;
}
function buildTicks() {
	const ticks = [];
	for (let midi = 48; midi <= 84; midi++) {
		const pc = midi % 12;
		const name = NAMES[pc] ?? "C";
		const sharp = name.includes("♯");
		const isC = pc === 0;
		const oct = Math.floor(midi / 12) - 1;
		ticks.push({
			midi,
			x: (midi - 48) / 36,
			kind: isC ? "c" : sharp ? "sharp" : "natural",
			label: isC ? `${name}${oct}` : sharp ? "" : name
		});
	}
	return ticks;
}
var PITCH_TICKS = buildTicks();
var GUIDE_LINES = PITCH_TICKS.filter((tick) => {
	if (tick.x <= 0 || tick.x >= 1) return false;
	const pc = tick.midi % 12;
	return pc === 0 || pc === 5;
});
var WAVEFORMS = [
	"sine",
	"soft",
	"saw",
	"square",
	"duo"
];
var SHAPES = {
	sine: {
		a: "sine",
		b: null,
		detune: 0,
		aGain: .82,
		bGain: 0,
		filterMul: 0,
		filterQ: .4,
		fixedCutoff: 12e3
	},
	soft: {
		a: "triangle",
		b: null,
		detune: 0,
		aGain: .58,
		bGain: 0,
		filterMul: 8,
		filterQ: .35
	},
	saw: {
		a: "sawtooth",
		b: null,
		detune: 0,
		aGain: .24,
		bGain: 0,
		filterMul: 4.6,
		filterQ: .65
	},
	square: {
		a: "square",
		b: null,
		detune: 0,
		aGain: .18,
		bGain: 0,
		filterMul: 2.7,
		filterQ: 1.7
	},
	duo: {
		a: "sawtooth",
		b: "sawtooth",
		detune: 9,
		aGain: .16,
		bGain: .13,
		filterMul: 4.2,
		filterQ: .75
	}
};
var MAX_VIBRATO_CENTS = 30;
function isWaveform(value) {
	return WAVEFORMS.includes(value);
}
function parseWaveform(value) {
	return typeof value === "string" && isWaveform(value) ? value : null;
}
function makeHall(ctx) {
	const rate = ctx.sampleRate;
	const length = Math.floor(rate * 2.15);
	const buffer = ctx.createBuffer(2, length, rate);
	const echoes = [
		.013,
		.019,
		.029,
		.041,
		.057,
		.079
	];
	for (let ch = 0; ch < 2; ch++) {
		const data = buffer.getChannelData(ch);
		let seed = ch === 0 ? 19 : 97;
		const rand = () => {
			seed = (seed * 16807 + 11) % 2147483647;
			return seed / 2147483647 * 2 - 1;
		};
		let lp = 0;
		let hp = 0;
		for (let i = 0; i < length; i++) {
			const t = i / rate;
			const n = rand();
			const coeff = .07 + .62 * Math.min(1, t / 1.2);
			lp += coeff * (n - lp);
			hp += .012 * (lp - hp);
			const body = (lp - hp) * Math.exp(-t * 2.15);
			data[i] = body;
		}
		for (let idx = 0; idx < echoes.length; idx++) {
			const time = echoes[idx] ?? 0;
			const at = Math.floor((time + ch * .0037) * rate);
			if (at >= 0 && at < length) {
				const sign = idx % 2 === 0 ? 1 : -1;
				data[at] += sign * .42 * Math.exp(-idx * .32);
			}
		}
	}
	let peak = 0;
	for (let ch = 0; ch < 2; ch++) {
		const data = buffer.getChannelData(ch);
		for (let i = 0; i < data.length; i++) peak = Math.max(peak, Math.abs(data[i] ?? 0));
	}
	if (peak > 1e-5) {
		const norm = .8 / peak;
		for (let ch = 0; ch < 2; ch++) {
			const data = buffer.getChannelData(ch);
			for (let i = 0; i < data.length; i++) data[i] = (data[i] ?? 0) * norm;
		}
	}
	return buffer;
}
function ramp(param, value, now, tc) {
	param.setTargetAtTime(value, now, tc);
}
/**
* Continuous theremin voice. The AudioContext is created on the first user
* gesture so mobile browsers actually unblock sound.
*/
var ThereminEngine = class {
	ctx = null;
	oscA = null;
	oscB = null;
	gainA = null;
	gainB = null;
	filter = null;
	voice = null;
	panner = null;
	dry = null;
	wet = null;
	lfo = null;
	lfoDepth = null;
	waveform = "sine";
	reverb = .36;
	vibrato = .4;
	x = .5;
	y = .5;
	active = false;
	pageVisible = true;
	unlock() {
		try {
			const w = window;
			const Ctor = window.AudioContext ?? w.webkitAudioContext;
			if (!Ctor) return false;
			if (!this.ctx) {
				this.ctx = new Ctor({ latencyHint: "interactive" });
				this.build(this.ctx);
			}
			if (this.ctx.state === "suspended") this.ctx.resume();
			return true;
		} catch {
			return false;
		}
	}
	setWaveform(id) {
		this.waveform = id;
		this.applyShape(.03);
		this.syncPitch(.04);
	}
	setReverb(amount) {
		this.reverb = clamp01(amount);
		this.applyMix(.06);
	}
	setVibrato(amount) {
		this.vibrato = clamp01(amount);
		this.syncPitch(.05);
	}
	/** `active` is false when the hand is away, the instrument is muted, or audio is locked. */
	setHand(x, y, active) {
		this.x = clamp01(x);
		this.y = clamp01(y);
		this.active = active;
		this.syncPitch(.018);
		this.syncLevel(active ? .03 : .055);
		this.syncPan(.04);
	}
	setPageVisible(visible) {
		this.pageVisible = visible;
		if (visible && this.ctx?.state === "suspended") this.ctx.resume();
		this.syncLevel(visible ? .04 : .03);
	}
	dispose() {
		const ctx = this.ctx;
		this.ctx = null;
		try {
			this.oscA?.stop();
			this.oscB?.stop();
			this.lfo?.stop();
		} catch {}
		if (ctx) ctx.close();
	}
	build(ctx) {
		const oscA = ctx.createOscillator();
		const oscB = ctx.createOscillator();
		const gainA = ctx.createGain();
		const gainB = ctx.createGain();
		const filter = ctx.createBiquadFilter();
		filter.type = "lowpass";
		const voice = ctx.createGain();
		voice.gain.value = 0;
		const panner = ctx.createStereoPanner();
		const dry = ctx.createGain();
		const wet = ctx.createGain();
		const predelay = ctx.createDelay(.1);
		predelay.delayTime.value = .02;
		const wetHp = ctx.createBiquadFilter();
		wetHp.type = "highpass";
		wetHp.frequency.value = 180;
		const wetLp = ctx.createBiquadFilter();
		wetLp.type = "lowpass";
		wetLp.frequency.value = 6200;
		const convolver = ctx.createConvolver();
		convolver.buffer = makeHall(ctx);
		const sum = ctx.createGain();
		const comp = ctx.createDynamicsCompressor();
		comp.threshold.value = -16;
		comp.knee.value = 18;
		comp.ratio.value = 2.4;
		comp.attack.value = .006;
		comp.release.value = .2;
		const hip = ctx.createBiquadFilter();
		hip.type = "highpass";
		hip.frequency.value = 32;
		const master = ctx.createGain();
		master.gain.value = .78;
		const lfo = ctx.createOscillator();
		lfo.type = "sine";
		lfo.frequency.value = 5.35;
		const lfoDepth = ctx.createGain();
		lfoDepth.gain.value = 0;
		oscA.connect(gainA);
		oscB.connect(gainB);
		gainA.connect(filter);
		gainB.connect(filter);
		filter.connect(voice);
		voice.connect(panner);
		panner.connect(dry);
		dry.connect(sum);
		panner.connect(predelay);
		predelay.connect(wetHp);
		wetHp.connect(wetLp);
		wetLp.connect(convolver);
		convolver.connect(wet);
		wet.connect(sum);
		sum.connect(comp);
		comp.connect(hip);
		hip.connect(master);
		master.connect(ctx.destination);
		lfo.connect(lfoDepth);
		lfoDepth.connect(oscA.frequency);
		lfoDepth.connect(oscB.frequency);
		oscA.frequency.value = 440;
		oscB.frequency.value = 440;
		oscA.start();
		oscB.start();
		lfo.start();
		this.oscA = oscA;
		this.oscB = oscB;
		this.gainA = gainA;
		this.gainB = gainB;
		this.filter = filter;
		this.voice = voice;
		this.panner = panner;
		this.dry = dry;
		this.wet = wet;
		this.lfo = lfo;
		this.lfoDepth = lfoDepth;
		this.applyShape(.01);
		this.applyMix(.01);
		this.syncPitch(.01);
		this.syncLevel(.01);
		this.syncPan(.01);
	}
	now() {
		return this.ctx ? this.ctx.currentTime : null;
	}
	applyShape(tc) {
		const now = this.now();
		if (!now || !this.oscA || !this.oscB || !this.gainA || !this.gainB || !this.filter) return;
		const shape = SHAPES[this.waveform];
		this.oscA.type = shape.a;
		this.oscB.type = shape.b ?? "sine";
		ramp(this.gainA.gain, shape.aGain, now, tc);
		ramp(this.gainB.gain, shape.b ? shape.bGain : 0, now, tc);
		ramp(this.oscB.detune, shape.detune, now, tc);
		ramp(this.filter.Q, shape.filterQ, now, tc);
	}
	applyMix(tc) {
		const now = this.now();
		if (!now || !this.dry || !this.wet) return;
		ramp(this.wet.gain, this.reverb * .48, now, tc);
		ramp(this.dry.gain, 1 - this.reverb * .2, now, tc);
	}
	syncPitch(tc) {
		const now = this.now();
		if (!now || !this.oscA || !this.oscB || !this.filter || !this.lfoDepth) return;
		const freq = xToFreq(this.x);
		ramp(this.oscA.frequency, freq, now, tc);
		ramp(this.oscB.frequency, freq, now, tc);
		const shape = SHAPES[this.waveform];
		const level = this.audibleLevel();
		const openness = .68 + .32 * Math.sqrt(level);
		const cutoff = shape.fixedCutoff ? shape.fixedCutoff : Math.min(8600, Math.max(380, freq * shape.filterMul * openness));
		ramp(this.filter.frequency, cutoff, now, .045);
		const deviation = freq * (this.vibrato * MAX_VIBRATO_CENTS) * (Math.LN2 / 1200);
		ramp(this.lfoDepth.gain, deviation, now, .06);
	}
	syncLevel(tc) {
		const now = this.now();
		if (!now || !this.voice) return;
		ramp(this.voice.gain, this.audibleLevel(), now, tc);
	}
	syncPan(tc) {
		const now = this.now();
		if (!now || !this.panner) return;
		ramp(this.panner.pan, (this.x - .5) * .55, now, tc);
	}
	audibleLevel() {
		if (!this.active || !this.pageVisible) return 0;
		return volumeFromY(this.y);
	}
};
var STORAGE_KEY = "aether-settings-v1";
var WAVES = [
	{
		id: "sine",
		label: "Sine",
		hint: "Pure tone"
	},
	{
		id: "soft",
		label: "Soft",
		hint: "Rounded triangle"
	},
	{
		id: "saw",
		label: "Saw",
		hint: "Bright sawtooth"
	},
	{
		id: "square",
		label: "Square",
		hint: "Hollow reed"
	},
	{
		id: "duo",
		label: "Duo",
		hint: "Two detuned saws"
	}
];
var DEFAULTS = {
	waveform: "sine",
	reverb: .36,
	vibrato: .4
};
function loadSettings() {
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		const waveform = parseWaveform(parsed.waveform);
		if (!waveform) return null;
		if (typeof parsed.reverb !== "number" || typeof parsed.vibrato !== "number") return null;
		return {
			waveform,
			reverb: clamp01(parsed.reverb),
			vibrato: clamp01(parsed.vibrato)
		};
	} catch {
		return null;
	}
}
function saveSettings(settings) {
	try {
		localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
	} catch {}
}
function Theremin() {
	const engineRef = (0, import_react.useRef)(null);
	const stageRef = (0, import_react.useRef)(null);
	const frameRef = (0, import_react.useRef)(0);
	const pendingRef = (0, import_react.useRef)(null);
	const xRef = (0, import_react.useRef)(HOME_X);
	const yRef = (0, import_react.useRef)(HOME_Y);
	const insideRef = (0, import_react.useRef)(false);
	const touchingRef = (0, import_react.useRef)(false);
	const awakeRef = (0, import_react.useRef)(false);
	const mutedRef = (0, import_react.useRef)(false);
	const settingsRef = (0, import_react.useRef)(DEFAULTS);
	const toggleMuteRef = (0, import_react.useRef)(() => {});
	const [hand, setHand] = (0, import_react.useState)({
		x: HOME_X,
		y: HOME_Y,
		sounding: false
	});
	const [awake, setAwake] = (0, import_react.useState)(false);
	const [muted, setMuted] = (0, import_react.useState)(false);
	const [waveform, setWaveform] = (0, import_react.useState)(DEFAULTS.waveform);
	const [reverb, setReverb] = (0, import_react.useState)(DEFAULTS.reverb);
	const [vibrato, setVibrato] = (0, import_react.useState)(DEFAULTS.vibrato);
	const [audioError, setAudioError] = (0, import_react.useState)(false);
	settingsRef.current = {
		waveform,
		reverb,
		vibrato
	};
	awakeRef.current = awake;
	mutedRef.current = muted;
	(0, import_react.useLayoutEffect)(() => {
		const engine = new ThereminEngine();
		engineRef.current = engine;
		const saved = loadSettings();
		if (saved) {
			settingsRef.current = saved;
			setWaveform(saved.waveform);
			setReverb(saved.reverb);
			setVibrato(saved.vibrato);
		}
		const initial = settingsRef.current;
		engine.setWaveform(initial.waveform);
		engine.setReverb(initial.reverb);
		engine.setVibrato(initial.vibrato);
		const onVis = () => {
			engine.setPageVisible(document.visibilityState !== "hidden");
		};
		const onKey = (event) => {
			if (event.key.toLowerCase() !== "m") return;
			const target = event.target;
			if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) return;
			event.preventDefault();
			toggleMuteRef.current();
		};
		document.addEventListener("visibilitychange", onVis);
		window.addEventListener("keydown", onKey);
		return () => {
			document.removeEventListener("visibilitychange", onVis);
			window.removeEventListener("keydown", onKey);
			if (frameRef.current) cancelAnimationFrame(frameRef.current);
			engine.dispose();
			engineRef.current = null;
		};
	}, []);
	function commit(x, y, sounding) {
		xRef.current = x;
		yRef.current = y;
		engineRef.current?.setHand(x, y, sounding);
		pendingRef.current = {
			x,
			y,
			sounding
		};
		if (frameRef.current) return;
		frameRef.current = requestAnimationFrame(() => {
			frameRef.current = 0;
			const next = pendingRef.current;
			if (!next) return;
			setHand((prev) => prev.x === next.x && prev.y === next.y && prev.sounding === next.sounding ? prev : next);
		});
	}
	function wake() {
		if (!(engineRef.current?.unlock() ?? false)) setAudioError(true);
		if (!awakeRef.current) {
			awakeRef.current = true;
			setAwake(true);
		}
	}
	function toggleMute() {
		const next = !mutedRef.current;
		mutedRef.current = next;
		setMuted(next);
		const sounding = !next && awakeRef.current && insideRef.current;
		commit(xRef.current, yRef.current, sounding);
	}
	toggleMuteRef.current = toggleMute;
	function pointFromEvent(event) {
		const rect = event.currentTarget.getBoundingClientRect();
		const rawX = rect.width ? (event.clientX - rect.left) / rect.width : 0;
		const rawY = rect.height ? (event.clientY - rect.top) / rect.height : 0;
		const inside = rawX >= 0 && rawX <= 1 && rawY >= 0 && rawY <= 1;
		return {
			x: clamp01(rawX),
			y: clamp01(rawY),
			inside
		};
	}
	function onPointerDown(event) {
		if (event.pointerType !== "mouse") event.preventDefault();
		wake();
		event.currentTarget.focus({ preventScroll: true });
		if (event.pointerType !== "mouse") {
			touchingRef.current = true;
			event.currentTarget.setPointerCapture(event.pointerId);
		}
		const point = pointFromEvent(event);
		insideRef.current = point.inside;
		const sounding = point.inside && !mutedRef.current;
		commit(point.x, point.y, sounding);
	}
	function onPointerMove(event) {
		const isMouse = event.pointerType === "mouse";
		if (!isMouse && !touchingRef.current) return;
		const point = pointFromEvent(event);
		insideRef.current = point.inside;
		const sounding = (isMouse || touchingRef.current) && point.inside && awakeRef.current && !mutedRef.current;
		commit(point.x, point.y, sounding);
	}
	function onPointerUp(event) {
		if (event.pointerType === "mouse") return;
		touchingRef.current = false;
		insideRef.current = false;
		commit(xRef.current, yRef.current, false);
	}
	function onPointerLeave(event) {
		if (event.pointerType !== "mouse" || touchingRef.current) return;
		insideRef.current = false;
		commit(xRef.current, yRef.current, false);
	}
	function onKeyDown(event) {
		const step = event.shiftKey ? .006 : .02;
		let x = xRef.current;
		let y = yRef.current;
		if (event.key === "ArrowLeft") x -= step;
		else if (event.key === "ArrowRight") x += step;
		else if (event.key === "ArrowUp") y -= step;
		else if (event.key === "ArrowDown") y += step;
		else return;
		event.preventDefault();
		wake();
		x = clamp01(x);
		y = clamp01(y);
		insideRef.current = true;
		commit(x, y, !mutedRef.current);
	}
	function chooseWave(id) {
		setWaveform(id);
		engineRef.current?.setWaveform(id);
		saveSettings({
			...settingsRef.current,
			waveform: id
		});
	}
	function changeReverb(value) {
		const next = clamp01(value);
		setReverb(next);
		engineRef.current?.setReverb(next);
		saveSettings({
			...settingsRef.current,
			reverb: next
		});
	}
	function changeVibrato(value) {
		const next = clamp01(value);
		setVibrato(next);
		engineRef.current?.setVibrato(next);
		saveSettings({
			...settingsRef.current,
			vibrato: next
		});
	}
	const pitch = describeX(hand.x);
	const laneX = (pitch.nearestMidi - 48) / 36;
	const loudness = 1 - hand.y;
	const handScale = .72 + loudness * .5;
	const wave = WAVES.find((item) => item.id === waveform) ?? WAVES[0];
	const status = audioError ? "Audio unavailable" : muted ? "Muted" : !awake ? "Press the field" : hand.sounding ? "" : "Hand away";
	const meta = status ? `${pitch.hz} Hz · ${formatCents(pitch.cents)} · ${status}` : `${pitch.hz} Hz · ${formatCents(pitch.cents)}`;
	const live = hand.sounding ? `${pitch.note}. Sounding` : muted ? `${pitch.note}. Muted` : !awake ? `${pitch.note}. Press the field` : `${pitch.note}. Silent`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "safe-bottom mx-auto flex min-h-dvh w-full flex-col px-3 pt-4 sm:px-6 sm:pt-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "sr-only",
				"aria-live": "polite",
				children: live
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-3 flex flex-wrap items-center gap-x-3 gap-y-1 sm:mb-4 sm:flex-nowrap",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-3xl leading-none tracking-tight text-balance text-fg sm:text-4xl",
							children: "Aether"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: "Field theremin"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						"aria-pressed": muted,
						"aria-label": muted ? "Unmute" : "Mute",
						onClick: () => {
							if (!(engineRef.current?.unlock() ?? false)) setAudioError(true);
							toggleMute();
						},
						className: clsx("ml-auto inline-flex h-11 shrink-0 items-center gap-2 rounded-full pr-4 pl-3.5 text-sm font-medium transition-[background-color,color,scale] duration-150 ease-out active:scale-[0.96] sm:order-3 sm:ml-0", muted ? "bg-brass text-bg" : "bg-panel text-fg shadow-panel"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MuteGlyph, { muted }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-grid",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: clsx("col-start-1 row-start-1", muted && "invisible"),
								children: "Mute"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: clsx("col-start-1 row-start-1", !muted && "invisible"),
								children: "Muted"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "order-3 w-full text-center sm:order-2 sm:w-auto sm:flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative inline-block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: clsx("tone-dot absolute top-1/2 -left-4 size-2 -translate-y-1/2 rounded-full bg-brass", hand.sounding ? "opacity-100" : "opacity-0"),
								"aria-hidden": "true"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-4xl leading-none tabular-nums text-fg sm:text-5xl",
								"data-note": pitch.note,
								"data-hz": pitch.hz,
								"data-sounding": hand.sounding ? "true" : "false",
								children: pitch.note
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm tabular-nums text-muted",
							children: meta
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex min-h-96 flex-1 flex-col overflow-hidden rounded-3xl bg-panel shadow-panel",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-h-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex w-12 shrink-0 flex-col items-center gap-2 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-medium text-muted",
								children: "Loud"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "relative w-1 flex-1 rounded-full bg-fg/10",
								"aria-hidden": "true",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute inset-x-0 bottom-0 rounded-full bg-brass",
									style: { height: `${loudness * 100}%` }
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-medium text-muted",
								children: "Soft"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						ref: stageRef,
						role: "application",
						tabIndex: 0,
						"aria-label": "Play field. Move across to change pitch and up to raise volume. Arrow keys move the tone.",
						"aria-describedby": "field-legend",
						onPointerDown,
						onPointerMove,
						onPointerUp,
						onPointerCancel: onPointerUp,
						onPointerLeave,
						onKeyDown,
						className: "stage relative min-w-0 flex-1 cursor-crosshair touch-none select-none outline-none focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-brass",
						style: { ["--halo"]: `${8 + reverb * 36}px` },
						children: [
							GUIDE_LINES.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: clsx("pointer-events-none absolute inset-y-0 w-px", line.kind === "c" ? "bg-brass/40" : "bg-fg/10"),
								style: { left: `${line.x * 100}%` }
							}, line.midi)),
							[
								25,
								50,
								75
							].map((mark) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "pointer-events-none absolute inset-x-0 h-px bg-fg/10",
								style: { top: `${mark}%` }
							}, mark)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "pointer-events-none absolute inset-y-0 bg-brass/15",
								style: {
									left: `${laneX * 100}%`,
									width: `${100 / 36}%`,
									transform: "translateX(-50%)"
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: clsx("pointer-events-none absolute inset-y-0 w-0.5 -translate-x-1/2 bg-brass", hand.sounding ? "opacity-80" : "opacity-35"),
								style: { left: `${hand.x * 100}%` }
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: clsx("pointer-events-none absolute inset-x-0 h-0.5 -translate-y-1/2 bg-brass", hand.sounding ? "opacity-70" : "opacity-30"),
								style: { top: `${hand.y * 100}%` }
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: clsx("hand pointer-events-none absolute size-16 rounded-full sm:size-20", hand.sounding ? "opacity-95" : "opacity-50"),
								style: {
									left: `${hand.x * 100}%`,
									top: `${hand.y * 100}%`,
									transform: `translate(-50%, -50%) scale(${handScale})`
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-1/2 left-1/2 size-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-fg" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "pointer-events-none absolute bottom-3 left-3 text-xs font-medium text-muted",
								children: "Low"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "pointer-events-none absolute right-3 bottom-3 text-xs font-medium text-muted",
								children: "High"
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative ml-12 h-12 border-t border-fg/10",
					"aria-hidden": "true",
					children: PITCH_TICKS.map((tick) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute top-0 flex flex-col items-center",
						style: {
							left: `${tick.x * 100}%`,
							transform: tick.x === 0 ? "none" : tick.x === 1 ? "translateX(-100%)" : "translateX(-50%)"
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: clsx("w-px", tick.kind === "c" ? "h-3 bg-brass" : tick.kind === "natural" ? "h-2 bg-fg/30" : "h-1.5 bg-fg/15") }), tick.label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: clsx("mt-1 text-xs leading-none tabular-nums", tick.kind === "c" ? "text-muted" : "hidden text-fg/45 sm:block"),
							children: tick.label
						}) : null]
					}, tick.midi))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				id: "field-legend",
				className: "mt-3 text-center text-sm text-pretty text-muted",
				children: "Left is low pitch, right is high. Bottom is soft, top is loud."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 hidden text-center text-xs text-muted sm:block",
				children: "Arrow keys move the tone. M mutes. Hold Shift for smaller steps."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-3 rounded-2xl bg-panel px-3 py-3 shadow-panel sm:px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex items-baseline justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium text-fg",
							children: "Wave"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: wave?.hint
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-5 gap-1 rounded-full bg-inset p-1",
						role: "group",
						"aria-label": "Waveform",
						children: WAVES.map((item) => {
							const selected = item.id === waveform;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-pressed": selected,
								onClick: () => chooseWave(item.id),
								className: clsx("min-h-11 rounded-full px-1 text-xs font-medium whitespace-nowrap transition-[background-color,color,scale] duration-150 ease-out active:scale-[0.96] sm:text-sm", selected ? "bg-brass text-bg" : "text-muted hover:bg-bg hover:text-fg"),
								children: item.label
							}, item.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-2 gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mb-1 flex items-baseline justify-between gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium text-fg",
									children: "Room"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums text-muted",
									children: Math.round(reverb * 100)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "range",
								min: 0,
								max: 100,
								value: Math.round(reverb * 100),
								"aria-label": "Reverb amount",
								"aria-valuetext": `${Math.round(reverb * 100)} percent`,
								onChange: (event) => changeReverb(Number(event.target.value) / 100)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mb-1 flex items-baseline justify-between gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium text-fg",
									children: "Vibrato"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums text-muted",
									children: Math.round(vibrato * 100)
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "range",
								min: 0,
								max: 100,
								value: Math.round(vibrato * 100),
								"aria-label": "Vibrato depth",
								"aria-valuetext": `${Math.round(vibrato * 100)} percent`,
								onChange: (event) => changeVibrato(Number(event.target.value) / 100)
							})]
						})]
					})
				]
			})
		]
	});
}
function MuteGlyph({ muted }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "relative grid size-5 place-items-center",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, {
			className: clsx("col-start-1 row-start-1 size-5 transition-[opacity,scale,filter] duration-300 ease-[cubic-bezier(0.2,0,0,1)]", muted ? "scale-100 opacity-100 blur-none" : "scale-[0.25] opacity-0 blur-[4px]"),
			strokeWidth: 2
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, {
			className: clsx("col-start-1 row-start-1 size-5 transition-[opacity,scale,filter] duration-300 ease-[cubic-bezier(0.2,0,0,1)]", muted ? "scale-[0.25] opacity-0 blur-[4px]" : "scale-100 opacity-100 blur-none"),
			strokeWidth: 2
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Theremin, {});
}
//#endregion
export { Home as component };
